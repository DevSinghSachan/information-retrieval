#!/usr/bin/env sh

# ./buildmodels.sh <training corpus dir> <training edit1s file>

python models.py $1 $2
